#!/usr/bin/env python3
"""
Video Agent — turns a written script into a narrated video with voiceover.

Pipeline:
    script (.txt/.md)  ->  scenes  ->  voiceover (edge-tts / gTTS)
                                    ->  visuals (styled slides via Pillow)
                                    ->  final video (.mp4 + .srt captions)

Usage:
    python3 video_agent.py examples/sample_script.txt
    python3 video_agent.py script.txt -o out.mp4 --voice en-IN-NeerjaNeural
    python3 video_agent.py --list-voices

Author: Arena.ai agent
"""

from __future__ import annotations

import argparse
import asyncio
import re
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from gtts import gTTS
from moviepy import AudioFileClip, ImageClip, concatenate_videoclips

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

WIDTH, HEIGHT = 1280, 720
FPS = 24
SCENE_GAP_SEC = 0.5          # brief pause between scenes
TAIL_PAD_SEC = 0.8           # silence at the very end
DEFAULT_VOICE = "en-US-JennyNeural"
DEFAULT_TITLE = "AI Video Agent"

FONT_DIR = Path("/usr/share/fonts/truetype/dejavu")
FONT_BOLD = FONT_DIR / "DejaVuSans-Bold.ttf"
FONT_REG = FONT_DIR / "DejaVuSans.ttf"

# Rotating colour palettes for scene backgrounds (top, bottom, accent)
PALETTES = [
    ((24, 32, 68), (52, 78, 160), (120, 180, 255)),
    ((46, 24, 70), (102, 52, 150), (200, 150, 255)),
    ((12, 52, 58), (28, 110, 118), (130, 230, 210)),
    ((70, 28, 36), (150, 62, 74), (255, 170, 150)),
    ((30, 44, 32), (66, 110, 70), (170, 230, 160)),
    ((52, 40, 16), (130, 98, 32), (255, 214, 130)),
]


# ---------------------------------------------------------------------------
# Scene model + script parsing
# ---------------------------------------------------------------------------

@dataclass
class Scene:
    index: int
    title: str
    body: str
    audio_path: Path | None = None
    image_path: Path | None = None
    duration: float = 0.0
    start_time: float = 0.0
    meta: dict = field(default_factory=dict)


def parse_script(text: str) -> list[Scene]:
    """
    Split a script into scenes.

    Supported formats:
      1. Markdown-ish headers:  "## My Scene Title"
      2. Bracket markers:       "[Scene 2] Opening hook"
      3. Plain paragraphs:      blank-line separated blocks (auto-chunked)
    """
    text = text.replace("\r\n", "\n").strip()
    if not text:
        raise ValueError("Script is empty.")

    # Try header-based splitting first
    header_re = re.compile(r"^(?:##?\s+(.+)|\[Scene\s*\d*\]\s*(.*))$", re.M | re.I)
    matches = list(header_re.finditer(text))

    scenes: list[Scene] = []
    if matches:
        # Text before the first header becomes "intro" if non-empty
        preamble = text[: matches[0].start()].strip()
        parts = []
        if preamble:
            parts.append(("Introduction", preamble))
        for i, m in enumerate(matches):
            title = (m.group(1) or m.group(2) or "").strip() or f"Scene {i + 1}"
            start = m.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
            body = text[start:end].strip()
            if body:
                parts.append((title, body))
    else:
        # Paragraph-based: split on blank lines, chunk long text
        paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
        parts = []
        for para in paragraphs:
            for chunk in _chunk_text(para, max_chars=520):
                parts.append(("", chunk))

    for i, (title, body) in enumerate(parts):
        clean_body = re.sub(r"\s+", " ", body).strip()
        display_title = title or _auto_title(clean_body, i)
        scenes.append(Scene(index=i + 1, title=display_title, body=clean_body))

    return scenes


def _chunk_text(text: str, max_chars: int) -> list[str]:
    """Split long text on sentence boundaries under max_chars."""
    if len(text) <= max_chars:
        return [text]
    sentences = re.split(r"(?<=[.!?])\s+", text)
    chunks, current = [], ""
    for s in sentences:
        if current and len(current) + len(s) + 1 > max_chars:
            chunks.append(current.strip())
            current = s
        else:
            current = f"{current} {s}".strip()
    if current:
        chunks.append(current.strip())
    return chunks


def _auto_title(body: str, index: int) -> str:
    """Derive a short title from the first words of the body."""
    words = body.split()[:6]
    title = " ".join(words).rstrip(".,;:!?")
    return title if title else f"Scene {index + 1}"


# ---------------------------------------------------------------------------
# Voiceover generation
# ---------------------------------------------------------------------------

async def _edge_tts(text: str, voice: str, out_path: Path,
                    rate: str = "+0%", pitch: str = "+0Hz") -> None:
    import edge_tts

    communicate = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
    await communicate.save(str(out_path))


def synthesize_voiceover(text: str, out_path: Path, voice: str,
                         rate: str = "+0%", pitch: str = "+0Hz",
                         engine: str = "auto") -> str:
    """Generate speech audio. Returns the engine actually used."""
    if engine in ("auto", "edge"):
        try:
            asyncio.run(_edge_tts(text, voice, out_path, rate=rate, pitch=pitch))
            return "edge-tts"
        except Exception as exc:  # noqa: BLE001
            if engine == "edge":
                raise RuntimeError(f"edge-tts failed: {exc}") from exc
            print(f"  [warn] edge-tts failed ({exc}); falling back to gTTS.",
                  file=sys.stderr)

    gTTS(text=text, lang=_gtts_lang(voice)).save(str(out_path))
    return "gTTS"


def _gtts_lang(voice: str) -> str:
    """Map an edge-tts voice id like 'en-IN-NeerjaNeural' to a gTTS lang."""
    m = re.match(r"^([a-z]{2,3})(?:-|_)?", voice, re.I)
    return m.group(1).lower() if m else "en"


def list_voices() -> None:
    import edge_tts

    voices = asyncio.run(edge_tts.list_voices())
    voices = sorted(voices, key=lambda v: v["ShortName"])
    print(f"{len(voices)} voices available. Common picks:\n")
    featured = ["en-US-JennyNeural", "en-US-GuyNeural", "en-US-AriaNeural",
                "en-IN-NeerjaNeural", "en-IN-PrabhatNeural",
                "en-GB-SoniaNeural", "en-AU-NatashaNeural",
                "hi-IN-SwaraNeural", "hi-IN-MadhurNeural"]
    names = {v["ShortName"] for v in voices}
    for name in featured:
        if name in names:
            print(f"  {name}")
    print("\nAll voices:")
    for v in voices:
        print(f"  {v['ShortName']:<32} {v['Locale']:<8} {v['Gender']}")


# ---------------------------------------------------------------------------
# Visual generation (styled slides)
# ---------------------------------------------------------------------------

def _load_font(path: Path, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(str(path), size)


def _wrap(draw: ImageDraw.ImageDraw, text: str,
          font: ImageFont.FreeTypeFont, max_width: int) -> list[str]:
    lines: list[str] = []
    for paragraph in text.split("\n"):
        words = paragraph.split()
        if not words:
            continue
        current = words[0]
        for word in words[1:]:
            candidate = f"{current} {word}"
            if draw.textlength(candidate, font=font) <= max_width:
                current = candidate
            else:
                lines.append(current)
                current = word
        lines.append(current)
    return lines


def _gradient(size: tuple[int, int], top: tuple, bottom: tuple) -> Image.Image:
    w, h = size
    img = Image.new("RGB", size)
    px = img.load()
    for y in range(h):
        t = y / max(h - 1, 1)
        row = tuple(int(top[c] + (bottom[c] - top[c]) * t) for c in range(3))
        for x in range(w):
            px[x, y] = row
    return img


def render_slide(scene: Scene, video_title: str, out_path: Path) -> None:
    """Render one scene slide (1280x720) with title + body text."""
    top, bottom, accent = PALETTES[(scene.index - 1) % len(PALETTES)]
    img = _gradient((WIDTH, HEIGHT), top, bottom)
    draw = ImageDraw.Draw(img, "RGBA")

    # Decorative accent bar and soft corner glow
    draw.rectangle([0, 0, 14, HEIGHT], fill=accent + (255,))
    draw.ellipse([WIDTH - 380, -180, WIDTH + 160, 320], fill=accent + (36,))

    title_font = _load_font(FONT_BOLD, 52)
    body_font = _load_font(FONT_REG, 34)
    badge_font = _load_font(FONT_BOLD, 26)
    foot_font = _load_font(FONT_REG, 22)

    margin_x = 90
    max_width = WIDTH - 2 * margin_x

    # Scene badge
    badge = f"SCENE {scene.index}"
    bw = draw.textlength(badge, font=badge_font)
    draw.rounded_rectangle([margin_x, 84, margin_x + bw + 36, 132],
                           radius=12, fill=accent + (220,))
    draw.text((margin_x + 18, 96), badge, font=badge_font,
              fill=(255, 255, 255, 255))

    # Title
    title_lines = _wrap(draw, scene.title, title_font, max_width)
    y = 164
    for line in title_lines[:2]:
        draw.text((margin_x, y), line, font=title_font, fill=(255, 255, 255))
        y += 64

    # Divider
    y += 12
    draw.rectangle([margin_x, y, margin_x + 120, y + 5],
                   fill=accent + (255,))
    y += 40

    # Body (cap lines so text never collides with footer)
    body_lines = _wrap(draw, scene.body, body_font, max_width)
    max_body_lines = max(1, (HEIGHT - 130 - y) // 48)
    visible = body_lines[:max_body_lines]
    if len(body_lines) > max_body_lines:
        if visible:
            visible[-1] = visible[-1].rsplit(" ", 1)[0] + " …"
    fill = (235, 238, 248, 255)
    for line in visible:
        draw.text((margin_x, y), line, font=body_font, fill=fill)
        y += 48

    # Footer
    footer = f"{video_title}   •   {scene.index}"
    draw.text((margin_x, HEIGHT - 52), footer, font=foot_font,
              fill=(200, 205, 220, 220))

    img.save(out_path, "PNG")


# ---------------------------------------------------------------------------
# Video assembly + captions
# ---------------------------------------------------------------------------

def write_srt(scenes: list[Scene], out_path: Path) -> None:
    """Write an SRT captions file from scene timings."""

    def fmt(t: float) -> str:
        ms = int(round(t * 1000))
        h, ms = divmod(ms, 3_600_000)
        m, ms = divmod(ms, 60_000)
        s, ms = divmod(ms, 1000)
        return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

    lines = []
    for i, sc in enumerate(scenes, 1):
        start = sc.start_time + 0.15
        end = sc.start_time + max(sc.duration - 0.2, 0.4)
        # Split long scene text into 2 caption chunks for readability
        body = sc.body
        chunks = _chunk_text(body, max_chars=180)
        span = (end - start) / len(chunks)
        for j, chunk in enumerate(chunks):
            lines.append(str(i + j))
            lines.append(f"{fmt(start + j * span)} --> {fmt(start + (j + 1) * span)}")
            lines.append(chunk)
            lines.append("")
    out_path.write_text("\n".join(lines), encoding="utf-8")


def assemble_video(scenes: list[Scene], out_path: Path, fps: int = FPS) -> None:
    clips = []
    for sc in scenes:
        audio = AudioFileClip(str(sc.audio_path))
        sc.duration = audio.duration
        img = ImageClip(str(sc.image_path)).with_duration(sc.duration + SCENE_GAP_SEC)
        clip = img.with_audio(audio.with_start(0))
        clips.append(clip)

    video = concatenate_videoclips(clips, method="chain")
    video.write_videofile(
        str(out_path),
        fps=fps,
        codec="libx264",
        audio_codec="aac",
        preset="medium",
        threads=4,
        logger=None,
    )
    video.close()
    for clip in clips:
        clip.close()


# ---------------------------------------------------------------------------
# Agent orchestration
# ---------------------------------------------------------------------------

def run_agent(script_path: Path, output_path: Path, video_title: str,
              voice: str, engine: str, captions: bool,
              rate: str, pitch: str, fps: int) -> Path:
    text = script_path.read_text(encoding="utf-8")
    scenes = parse_script(text)
    print(f"[1/4] Parsed script: {len(scenes)} scene(s).")

    workdir = Path(tempfile.mkdtemp(prefix="video_agent_"))
    print(f"[2/4] Generating voiceover (voice: {voice}) …")
    for sc in scenes:
        audio_path = workdir / f"scene_{sc.index:02d}.mp3"
        used = synthesize_voiceover(sc.body, audio_path, voice,
                                    rate=rate, pitch=pitch, engine=engine)
        sc.audio_path = audio_path
        print(f"      scene {sc.index}: audio done ({used})")

    print("[3/4] Rendering visuals …")
    for sc in scenes:
        image_path = workdir / f"scene_{sc.index:02d}.png"
        render_slide(sc, video_title, image_path)
        sc.image_path = image_path

    # Timing map for captions
    t = 0.0
    for sc in scenes:
        audio = AudioFileClip(str(sc.audio_path))
        sc.duration = audio.duration
        sc.start_time = t
        t += sc.duration + SCENE_GAP_SEC
        audio.close()

    print("[4/4] Assembling video …")
    assemble_video(scenes, output_path, fps=fps)

    if captions:
        srt_path = output_path.with_suffix(".srt")
        write_srt(scenes, srt_path)
        print(f"      captions: {srt_path}")

    total = sum(sc.duration for sc in scenes)
    print(f"\nDone! Video: {output_path}  ({total:.1f}s of narration, "
          f"{len(scenes)} scenes)")
    return output_path


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Video Agent — script in, narrated video out.")
    parser.add_argument("script", nargs="?",
                        help="Path to the script (.txt or .md)")
    parser.add_argument("-o", "--output", default="output_video.mp4",
                        help="Output mp4 path (default: output_video.mp4)")
    parser.add_argument("-t", "--title", default=DEFAULT_TITLE,
                        help=f"Video title shown on slides (default: {DEFAULT_TITLE})")
    parser.add_argument("--voice", default=DEFAULT_VOICE,
                        help=f"edge-tts voice id (default: {DEFAULT_VOICE})")
    parser.add_argument("--engine", choices=["auto", "edge", "gtts"],
                        default="auto",
                        help="TTS engine: auto (edge-tts, gTTS fallback), "
                             "edge, or gtts")
    parser.add_argument("--rate", default="+0%",
                        help="Speech rate, e.g. +10%% or -5%%")
    parser.add_argument("--pitch", default="+0Hz",
                        help="Speech pitch, e.g. +2Hz or -3Hz")
    parser.add_argument("--no-captions", action="store_true",
                        help="Do not write the .srt captions file")
    parser.add_argument("--fps", type=int, default=FPS,
                        help=f"Output frames per second (default: {FPS})")
    parser.add_argument("--list-voices", action="store_true",
                        help="List available voiceover voices and exit")

    args = parser.parse_args()

    if args.list_voices:
        list_voices()
        return

    if not args.script:
        parser.error("script path is required (or use --list-voices)")

    script_path = Path(args.script)
    if not script_path.exists():
        parser.error(f"script not found: {script_path}")

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    run_agent(
        script_path=script_path,
        output_path=output_path,
        video_title=args.title,
        voice=args.voice,
        engine=args.engine,
        captions=not args.no_captions,
        rate=args.rate,
        pitch=args.pitch,
        fps=args.fps,
    )


if __name__ == "__main__":
    main()
